package org.example;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class Main {

    private static String dominio = "https://github.com";

    public static void main(String[] args) throws IOException, ExecutionException, InterruptedException {
        List<String> todasAsPaginas = obterURLDeTodasAsPaginas("Netflix");
        List<String> urlsDosRepositorios = obterUrlDosRepositorios(todasAsPaginas);
        List<DadosRepositorio> dadosRepositorios = rasparPaginaRepositorios(urlsDosRepositorios);
        System.out.println("FIM");
    }

    private static List<String> obterURLDeTodasAsPaginas(String usuario) throws IOException {
        // https://github.com/orgs/Netflix/repositories: Lógica funciona
        // https://github.com/orgs/microsoft/repositories: Não funciona, pois existem muitos repositórios, ao ponto do de não mostrar todos os botões
        // https://github.com/orgs/idwall/repositories: Não funciona, não tem paginação.

        String url = String.format("https://github.com/orgs/%s/repositories", usuario);
        Document documento = Jsoup.connect(url).get();
        var paginations = documento.getElementsByClass("pagination");
        Elements todasAsTagDoTipoA = paginations.get(0).select("a[href]");

        Set<String> paths = todasAsTagDoTipoA.stream().map(link-> link.attr("href")).collect(Collectors.toSet());
        List<String> paginasImcompleta = paths.stream().map(path-> dominio + path).toList();

        String pagina1 = String.format("https://github.com/orgs/%s/repositories?page=1", usuario);
        List todasAsPaginas = new ArrayList();
        todasAsPaginas.add(pagina1);
        todasAsPaginas.addAll(paginasImcompleta);

        return todasAsPaginas;
    }

    private static List<String> obterUrlDosRepositorios(List<String> todasAsPaginas) throws IOException {
        List<String> urlsDosRepositorios = new ArrayList<>();
        for (String url : todasAsPaginas) {
            Document pagina = Jsoup.connect(url).get();
            var urlRepositorio = pagina.getElementsByAttribute("data-hovercard-url");
            for(Element a : urlRepositorio) {
                urlsDosRepositorios.add(a.attr("href"));
            }
        }
        return urlsDosRepositorios;
    }

    private static List<DadosRepositorio> rasparPaginaRepositorios(List<String> urlsDosRepositorios) throws IOException {
        List<DadosRepositorio> todosDadosRepositorios = new ArrayList<>();
        for (String url: urlsDosRepositorios) {
            Document document = Jsoup.connect(dominio + url).get();
            String branches = document.getElementsByAttributeValue("href", url + "/branches").select("strong").html();
            String tags = document.getElementsByAttributeValue("href", url + "/tags").select("strong").html();
            String forks = document.getElementById("fork-button").select("span").html();
            String stars = document.getElementById("repo-stars-counter-star").html();
            String nome = url.split("/")[2];
            String urlCompleta = dominio+url;

            DadosRepositorio dadosRepositorio = new DadosRepositorio(nome, urlCompleta, branches, tags, forks, stars);
            todosDadosRepositorios.add(dadosRepositorio);
        }
        return todosDadosRepositorios;
    }
}