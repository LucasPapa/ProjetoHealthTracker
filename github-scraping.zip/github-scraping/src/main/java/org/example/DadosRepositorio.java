package org.example;

public record DadosRepositorio(String nome, String url, String branches, String tags, String forks, String stars) { }
